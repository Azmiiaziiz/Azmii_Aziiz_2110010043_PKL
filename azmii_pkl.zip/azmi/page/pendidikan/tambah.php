<div class="row">
    <div class="col-12">
        <div class="panel">
            <div class="panel-header">
                <h5>Pendidikan</h5>
            </div>
            <div class="panel-body">    
                <div class="card mb-20">
                    <div class="card-header">Tambah Data Pendidikan</div>
                    <div class="card-body">
                        <form method="post" enctype="multipart/form-data">
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Pendidikan</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="pendidikan" required>
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">&nbsp;</label>
                                <div class="col-sm-9">
                                	<button type="submit" name="tambah" class="btn btn-primary btn-sm">Simpan</button>
                                	<a href="?page=pendidikan" class="btn btn-danger btn-sm">Kembali</a>
                                </div>
                            </div> 
                        </form>
                        <?php  
                         
                        if (isset($_POST['tambah'])) {
                            $pendidikan = mysqli_real_escape_string($con, $_POST['pendidikan']);  
                         
                            $query = "INSERT INTO pendidikan (pendidikan) VALUES ('$pendidikan')";
                            if ($con->query($query) === TRUE) {
                                echo "<script>
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Berhasil!',
                                            text: 'Data berhasil disimpan.',
                                            confirmButtonText: 'OK'
                                        }).then((result) => {
                                            if (result.isConfirmed) {
                                                window.location.href = '?page=pendidikan';
                                            }
                                        });
                                      </script>";
                            } else {
                                echo "<script>
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Gagal!',
                                            text: 'Terjadi kesalahan saat menyimpan data.',
                                            confirmButtonText: 'OK'
                                        });
                                      </script>";
                            }
                        }
                        ?>
                    </div>
                </div> 
            </div>
        </div>
    </div>
</div>  