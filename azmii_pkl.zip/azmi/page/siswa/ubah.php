    
<?php
$nisn = $_GET['nisn'];
$sql = $con->query("SELECT * FROM siswa WHERE nisn='$nisn'");
$row = mysqli_fetch_assoc($sql);
?>

<div class="row">
    <div class="col-12">
        <div class="panel">
            <div class="panel-header">
                <h5>Siswa</h5>
            </div>
            <div class="panel-body"> 
                <div class="card mb-20">
                    <div class="card-header">Ubah Data Siswa <b>"<?= $row['nama']; ?>"</b></div>
                    <div class="card-body">
                        <form method="post" enctype="multipart/form-data"> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">NISN</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="nisn" value="<?= $row['nisn']; ?>" readonly required>
                                </div>
                            </div>  
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Nama</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="nama" value="<?= $row['nama']; ?>" required>
                                </div>
                            </div>   
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Kelas</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="id_kelas" required>
                                        <option selected disabled>Pilih</option>
                                        <?php
                                        $sql = mysqli_query($con, "SELECT * FROM kelas");
                                        while ($kar = mysqli_fetch_array($sql)) {
                                            $selected = ($row['id_kelas'] == $kar['id_kelas']) ? 'selected' : '';
                                            echo "<option value='$kar[id_kelas]' $selected>$kar[kelas]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Rombongan Belajar</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="id_rombel" required>
                                        <option selected disabled>Pilih</option>
                                        <?php
                                        $sql = mysqli_query($con, "SELECT * FROM rombel");
                                        while ($kar = mysqli_fetch_array($sql)) {
                                            $selected = ($row['id_rombel'] == $kar['id_rombel']) ? 'selected' : '';
                                            echo "<option value='$kar[id_rombel]' $selected>$kar[rombel]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div>
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Jenis Kelamin</label>
                                <div class="col-sm-9">
                                    <select name="jk" class="form-control" required>
                                        <option value="Laki-Laki" <?= ($row['jk'] == 'Laki-Laki') ? 'selected' : ''; ?>>Laki-Laki</option>
                                        <option value="Perempuan" <?= ($row['jk'] == 'Perempuan') ? 'selected' : ''; ?>>Perempuan</option>
                                    </select>
                                </div>
                            </div>   
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Tempat Lahir</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="tmp" value="<?= $row['tmp']; ?>" required>
                                </div>
                            </div>  
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Tanggal Lahir</label>
                                <div class="col-sm-9">
                                    <input type="date" class="form-control" name="tgl" value="<?= $row['tgl']; ?>" required>
                                </div>
                            </div>  
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">No Kartu Keluarga</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="no_kk" value="<?= $row['no_kk']; ?>" required>
                                </div>
                            </div>  
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Agama</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="id_agama" required>
                                        <option selected disabled>Pilih</option>
                                        <?php
                                        $sql = mysqli_query($con, "SELECT * FROM agama");
                                        while ($kar = mysqli_fetch_array($sql)) {
                                            $selected = ($row['id_agama'] == $kar['id_agama']) ? 'selected' : '';
                                            echo "<option value='$kar[id_agama]' $selected>$kar[agama]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div>  
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Bekebutuhan Khusus</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="id_khusus" required>
                                        <option selected disabled>Pilih</option>
                                        <?php
                                        $sql = mysqli_query($con, "SELECT * FROM khusus");
                                        while ($kar = mysqli_fetch_array($sql)) {
                                            $selected = ($row['id_khusus'] == $kar['id_khusus']) ? 'selected' : '';
                                            echo "<option value='$kar[id_khusus]' $selected>$kar[khusus]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div>  
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Alamat</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="alamat" value="<?= $row['alamat']; ?>" required>
                                </div>
                            </div>  
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">RT / RW</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="rt" value="<?= $row['rt']; ?>" required>
                                    <input type="text" class="form-control mt-2" name="rw" value="<?= $row['rw']; ?>" required>
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Provinsi</label>
                                <div class="col-sm-9"> 
                                    <select class="form-control mb-2" required name="provinsi" id="form_prov">
                                        <option selected value="" disabled></option>
                                        <?php 
                                        $daerah = mysqli_query($con,"SELECT kode,nama FROM wilayah_2022 WHERE CHAR_LENGTH(kode)=2 ORDER BY nama");
                                        while($d = mysqli_fetch_array($daerah)){
                                            ?>
                                            <option value="<?php echo $d['kode']; ?>"><?php echo $d['nama']; ?></option>
                                            <?php 
                                        }
                                        ?>
                                    </select> 

                                    <select class="form-control mb-2" required name="kabupaten" id="form_kab"></select>  

                                    <select class="form-control mb-2" required name="kecamatan" id="form_kec"></select> 

                                    <select class="form-control" required name="desa" id="form_des"></select> 
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Kode POS</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="kodepos" value="<?= $row['kodepos']; ?>" required>
                                </div>
                            </div>   
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Tempat Tinggal</label>
                                <div class="col-sm-9">
                                    <select name="tinggal_bersama" class="form-control" required>
                                        <option value="Bersama orang tua" <?= ($row['tinggal_bersama'] == 'Bersama orang tua') ? 'selected' : ''; ?>>Bersama orang tua</option>
                                        <option value="Wali" <?= ($row['tinggal_bersama'] == 'Wali') ? 'selected' : ''; ?>>Wali</option>
                                        <option value="Kos" <?= ($row['tinggal_bersama'] == 'Kos') ? 'selected' : ''; ?>>Kos</option>
                                        <option value="Asrama" <?= ($row['tinggal_bersama'] == 'Asrama') ? 'selected' : ''; ?>>Asrama</option>
                                        <option value="Panti Asuhan" <?= ($row['tinggal_bersama'] == 'Panti Asuhan') ? 'selected' : ''; ?>>Panti Asuhan</option>
                                        <option value="Pesantren" <?= ($row['tinggal_bersama'] == 'Pesantren') ? 'selected' : ''; ?>>Pesantren</option>
                                        <option value="Lainnya" <?= ($row['tinggal_bersama'] == 'Lainnya') ? 'selected' : ''; ?>>Lainnya</option>
                                    </select>
                                </div>
                            </div>  
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Transportasi</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="id_transportasi" required>
                                        <?php
                                        $sql = mysqli_query($con, "SELECT * FROM transportasi");
                                        while ($kar = mysqli_fetch_array($sql)) {
                                            $selected = ($row['id_transportasi'] == $kar['id_transportasi']) ? 'selected' : '';
                                            echo "<option value='$kar[id_transportasi]' $selected>$kar[transportasi]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div>  
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Anak Ke</label>
                                <div class="col-sm-9">
                                    <input type="number" class="form-control" name="anak_ke" value="<?= $row['anak_ke']; ?>" required>
                                </div>
                            </div>  
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Penerima KPS</label>
                                <div class="col-sm-9">
                                    <select name="penerima_kps" class="form-control mb-2" id="penerima_kps" onchange="toggleNoKPS()" required>
                                        <option value="Ya" <?= ($row['penerima_kps'] == 'Ya') ? 'selected' : ''; ?>>Ya</option>
                                        <option value="Tidak" <?= ($row['penerima_kps'] == 'Tidak') ? 'selected' : ''; ?>>Tidak</option>
                                    </select> 
                                    <input type="text" class="form-control mb-2" name="no_kps" id="no_kps_row" style="display: none;" value="<?= $row['no_kps']; ?>" placeholder="Nomor Penerima KPS">
                                </div>
                            </div>   
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Alasan Layak KIP</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="id_kelayakan" required>
                                        <option selected disabled>Pilih</option>
                                        <?php
                                        $sql = mysqli_query($con, "SELECT * FROM kelayakan");
                                        while ($kar = mysqli_fetch_array($sql)) {
                                            $selected = ($row['id_kelayakan'] == $kar['id_kelayakan']) ? 'selected' : '';
                                            echo "<option value='$kar[id_kelayakan]' $selected>$kar[kelayakan]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div>  
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Penerima KIP</label>
                                <div class="col-sm-9">
                                    <select name="penerima_kip" class="form-control mb-2" required id="penerima_kip" onchange="toggleKIPDetails()">
                                        <option value="Ya" <?= ($row['penerima_kip'] == 'Ya') ? 'selected' : ''; ?>>Ya</option>
                                        <option value="Tidak" <?= ($row['penerima_kip'] == 'Tidak') ? 'selected' : ''; ?>>Tidak</option>
                                    </select>  

                                    <input type="text" class="form-control mb-2" name="no_kip" id="no_kip" value="<?= $row['no_kip']; ?>" placeholder="Masukkan Nomor KIP" style="display: none;">
                                    <input type="text" class="form-control mb-2" name="nama_tertera" id="nama_tertera" value="<?= $row['nama_tertera']; ?>" placeholder="Masukkan Nama Tertera" style="display: none;">
                                    <input type="text" class="form-control mb-2" name="terima_kartu" id="terima_kartu" value="<?= $row['terima_kartu']; ?>" placeholder="Masukkan Terima Kartu" style="display: none;">
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">&nbsp;</label>
                                <div class="col-sm-9">
                                	<button type="submit" name="ubah" class="btn btn-success btn-sm">Ubah</button>
                                	<a href="?page=siswa" class="btn btn-danger btn-sm">Kembali</a>
                                </div>
                            </div> 
                        </form>
                        <?php 
                            if (isset($_POST['ubah']) && !empty($nisn)) { 
                                $nisn = mysqli_real_escape_string($con, $_POST['nisn']);
                                $nama = mysqli_real_escape_string($con, $_POST['nama']);
                                $jk = mysqli_real_escape_string($con, $_POST['jk']);
                                $tmp = mysqli_real_escape_string($con, $_POST['tmp']);
                                $tgl = mysqli_real_escape_string($con, $_POST['tgl']);
                                $no_kk = mysqli_real_escape_string($con, $_POST['no_kk']);
                                $id_agama = mysqli_real_escape_string($con, $_POST['id_agama']);
                                $id_khusus = mysqli_real_escape_string($con, $_POST['id_khusus']);
                                $alamat = mysqli_real_escape_string($con, $_POST['alamat']);
                                $rt = mysqli_real_escape_string($con, $_POST['rt']);
                                $rw = mysqli_real_escape_string($con, $_POST['rw']);
                                $provinsi = mysqli_real_escape_string($con, $_POST['provinsi']);
                                $kabupaten = mysqli_real_escape_string($con, $_POST['kabupaten']);
                                $kecamatan = mysqli_real_escape_string($con, $_POST['kecamatan']);
                                $desa = mysqli_real_escape_string($con, $_POST['desa']);
                                $kodepos = mysqli_real_escape_string($con, $_POST['kodepos']);
                                $tinggal_bersama = mysqli_real_escape_string($con, $_POST['tinggal_bersama']);
                                $id_transportasi = mysqli_real_escape_string($con, $_POST['id_transportasi']);
                                $anak_ke = mysqli_real_escape_string($con, $_POST['anak_ke']);
                                $penerima_kps = mysqli_real_escape_string($con, $_POST['penerima_kps']);
                                $no_kps = mysqli_real_escape_string($con, $_POST['no_kps']);
                                $id_kelayakan = mysqli_real_escape_string($con, $_POST['id_kelayakan']);
                                $penerima_kip = mysqli_real_escape_string($con, $_POST['penerima_kip']);
                                $no_kip = mysqli_real_escape_string($con, $_POST['no_kip']);
                                $nama_tertera = mysqli_real_escape_string($con, $_POST['nama_tertera']);
                                $terima_kartu = mysqli_real_escape_string($con, $_POST['terima_kartu']);
                                $id_kelas = mysqli_real_escape_string($con, $_POST['id_kelas']);
                                $id_rombel = mysqli_real_escape_string($con, $_POST['id_rombel']);
                             
                                $query = "UPDATE siswa SET
                                          nama='$nama',
                                          jk='$jk',
                                          tmp='$tmp',
                                          tgl='$tgl',
                                          no_kk='$no_kk',
                                          id_agama='$id_agama',
                                          id_khusus='$id_khusus',
                                          alamat='$alamat',
                                          rt='$rt',
                                          rw='$rw',
                                          provinsi='$provinsi',
                                          kabupaten='$kabupaten',
                                          kecamatan='$kecamatan',
                                          desa='$desa',
                                          kodepos='$kodepos',
                                          tinggal_bersama='$tinggal_bersama',
                                          id_transportasi='$id_transportasi',
                                          anak_ke='$anak_ke',
                                          penerima_kps='$penerima_kps',
                                          no_kps='$no_kps',
                                          id_kelayakan='$id_kelayakan',
                                          penerima_kip='$penerima_kip',
                                          no_kip='$no_kip',
                                          nama_tertera='$nama_tertera',
                                          terima_kartu='$terima_kartu',
                                          id_kelas='$id_kelas',
                                          id_rombel='$id_rombel'
                                          WHERE nisn='$nisn'";

                                if ($con->query($query) === TRUE) {
                                    echo "<script>
                                            Swal.fire({
                                                icon: 'success',
                                                title: 'Berhasil!',
                                                text: 'Data berhasil diperbarui.',
                                                confirmButtonText: 'OK'
                                            }).then((result) => {
                                                if (result.isConfirmed) {
                                                    window.location.href = '?page=siswa';
                                                }
                                            });
                                          </script>";
                                } else {
                                    echo "<script>
                                            Swal.fire({
                                                icon: 'error',
                                                title: 'Gagal!',
                                                text: 'Terjadi kesalahan saat memperbarui data.',
                                                confirmButtonText: 'OK'
                                            });
                                          </script>";
                                }
                            }
                        ?>
                    </div>
                </div> 
            </div>
        </div>
    </div>
</div> 



<script>
    document.addEventListener("DOMContentLoaded", function () { 
        function toggleNoKPS() {
            const penerimaKPS = document.getElementById("penerima_kps").value;
            const noKPSRow = document.getElementById("no_kps_row");
            noKPSRow.style.display = penerimaKPS === "Ya" ? "block" : "none";
        }
 
        function toggleKIPDetails() {
            const penerimaKIP = document.getElementById("penerima_kip").value;
            const noKIP = document.getElementById("no_kip");
            const namaTertera = document.getElementById("nama_tertera");
            const terimaKartu = document.getElementById("terima_kartu");
            
            const isKIP = penerimaKIP === "Ya";
            noKIP.style.display = isKIP ? "block" : "none";
            namaTertera.style.display = isKIP ? "block" : "none";
            terimaKartu.style.display = isKIP ? "block" : "none";
        }
 
        toggleNoKPS();
        toggleKIPDetails();

        // Event listener
        document.getElementById("penerima_kps").addEventListener("change", toggleNoKPS);
        document.getElementById("penerima_kip").addEventListener("change", toggleKIPDetails);
    });
</script>