<div class="row">
    <div class="col-12">
        <div class="panel">
            <div class="panel-header">
                <h5>Siswa</h5>
            </div>
            <div class="panel-body">  
                <div class="card mb-20">
                    <div class="card-header">
                        Data Siswa
                        <a href="?page=siswa&aksi=tambah" class="btn btn-primary btn-sm float-end">Tambah</a>
                    </div>
                    <div class="card-body">
                        <table class="table table-dashed table-bordered table-hover digi-dataTable table-striped" id="componentDataTable">
                            <thead>
                                <tr>
                                    <th width="5" style="vertical-align: top; text-align: center;">No.</th>
                                    <th style="vertical-align: top; text-align: center;">NISN</th> 
                                    <th style="vertical-align: top; text-align: left;">Nama</th> 
                                    <th style="vertical-align: top; text-align: left;">Kelas</th>  
                                    <th style="vertical-align: top; text-align: center;">Jenis Kelamin</th> 
                                    <th style="vertical-align: top; text-align: left;">Tempat, Tanggal lahir</th> 
                                    <th style="vertical-align: top; text-align: left;">Alamat</th> 
                                    <th style="vertical-align: top; text-align: left;">Penerima KPS</th> 
                                    <th style="vertical-align: top; text-align: left;">Penerima KIP</th> 
                                    <th width="10" style="vertical-align: top; text-align: center;">#</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $nomor = 1; 
                                $ambil = $con->query("SELECT * FROM siswa NATURAL JOIN kelas NATURAL JOIN rombel ORDER BY nisn ASC"); 
                                while ($row = $ambil->fetch_assoc()) { 
                                    $tgl = tgl_indo($row['tgl']); ?>
                                    <tr>
                                        <td style="vertical-align: top; text-align: center;"><?= $nomor; ?></td>
                                        <td style="vertical-align: top; text-align: center;"><?= $row['nisn']; ?></td> 
                                        <td style="vertical-align: top; text-align: left;"><?= $row['nama']; ?></td> 
                                        <td style="vertical-align: top; text-align: left;">Kelas : <?= $row['kelas']; ?> <br> Rombel : <?= $row['rombel']; ?></td>  
                                        <td style="vertical-align: top; text-align: center;"><?= $row['jk']; ?></td> 
                                        <td style="vertical-align: top; text-align: left;"><?= $row['tmp']; ?>, <?= $tgl; ?></td> 
                                        <td style="vertical-align: top; text-align: left;"><?= $row['alamat']; ?></td> 
                                        <td style="vertical-align: top; text-align: left;">
                                            Terima : <?= $row['penerima_kps']; ?>
                                            <?php if ($row['penerima_kps'] === 'Ya'): ?>
                                                <br> No : <?= $row['no_kps']; ?>
                                            <?php endif; ?>
                                        </td> 
                                        <td style="vertical-align: top; text-align: left;">
                                            Terima : <?= $row['penerima_kip']; ?>
                                            <?php if ($row['penerima_kip'] === 'Ya'): ?>
                                                <br> No : <?= $row['no_kip']; ?> 
                                                <br> Nama : <?= $row['nama_tertera']; ?> 
                                                <br> Kartu : <?= $row['terima_kartu']; ?>
                                            <?php endif; ?> 
                                        </td> 
                                        <td style="vertical-align: top; text-align: center;">
                                            <div class="dropdown">
                                                <button class="btn btn-warning dropdown-toggle btn-sm" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="fa-regular fa-cogs"></i>
                                                </button>
                                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                    <li><a class="dropdown-item" href="?page=siswa&aksi=lihat&nisn=<?= $row['nisn'] ?>">Lihat</a></li>
                                                    <li><a class="dropdown-item" href="?page=siswa&aksi=ubah&nisn=<?= $row['nisn'] ?>">Ubah</a></li>
                                                    <li><a class="dropdown-item" href="javascript:void(0)" onclick="confirmDelete(<?= $row['nisn']; ?>)">Hapus</a></li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                <?php 
                                $nomor++; 
                                } ?>
                            </tbody>
                        </table>
                    </div>
                </div> 
            </div>
        </div>
    </div>
</div> 

<script>
function confirmDelete(nisn) {
    Swal.fire({
        title: 'Apakah Anda yakin?',
        text: "Anda tidak bisa mengembalikan data yang telah dihapus!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = "?page=siswa&aksi=hapus&nisn=" + nisn;
        }
    });
}
</script> 

