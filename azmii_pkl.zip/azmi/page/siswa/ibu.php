<div class="row">
    <div class="col-12">
        <div class="panel">
            <div class="panel-header">
                <h5>Wali Siswa (Ibu)</h5>
            </div>
            <div class="panel-body">  
                <div class="card mb-20">
                    <div class="card-header">
                        Data Wali Siswa (Ibu) 
                    </div>
                    <div class="card-body">
                        <table class="table table-dashed table-bordered table-hover digi-dataTable table-striped" id="componentDataTable">
                            <thead>
                                <tr>
                                    <th width="5" style="vertical-align: middle; text-align: center;" rowspan="2">No.</th>
                                    <th style="vertical-align: middle; text-align: left;" rowspan="2">Siswa</th>  
                                    <th style="vertical-align: middle; text-align: center;" colspan="7">Data Wali Siswa (Ibu)</th>  
                                    <th style="vertical-align: middle; text-align: center;" rowspan="2">#</th>  
                                </tr>
                                <tr>
                                    <th style="vertical-align: top; text-align: left;">NIK</th>  
                                    <th style="vertical-align: top; text-align: left;">Nama</th>  
                                    <th style="vertical-align: top; text-align: left;">Tahun Lahir</th>  
                                    <th style="vertical-align: top; text-align: center;">Pendidikan</th>  
                                    <th style="vertical-align: top; text-align: center;">Pekerjaan</th>  
                                    <th style="vertical-align: top; text-align: right;">Penghasilan /Bulan</th>  
                                    <th style="vertical-align: top; text-align: center;">Berkebutuhan Khusus</th>  
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $nomor = 1; 
                                $query = $con->query("SELECT 
                                    siswa.nisn, 
                                    siswa.nama AS nama_siswa, 
                                    ibu.id_ibu, 
                                    ibu.nik_ibu, 
                                    ibu.nama_ibu, 
                                    ibu.tahun_lahir_ibu, 
                                    ibu.id_pendidikan, 
                                    ibu.id_pekerjaan, 
                                    ibu.penghasilan_ibu, 
                                    ibu.id_khusus
                                    FROM siswa
                                    LEFT JOIN ibu ON siswa.nisn = ibu.nisn
                                    ORDER BY siswa.nisn ASC"); 

                                while ($row = $query->fetch_assoc()) { ?>
                                    <tr>
                                        <td style="vertical-align: top; text-align: center;"><?= $nomor; ?></td>
                                        <td style="vertical-align: top; text-align: left;">
                                            NISN : <?= $row['nisn']; ?> <br> Nama : <?= $row['nama_siswa']; ?>
                                        </td>
                                        <?php if (empty($row['nik_ibu'])) { ?>
                                            <td colspan="7" style="color: red; text-align: center;">
                                                Wali Siswa (Ibu) belum diisi.
                                                <a href="?page=siswa&aksi=ibu_tambah&nisn=<?= $row['nisn'] ?>" class="btn btn-primary btn-sm text-white">Tambah data</a>
                                            </td>
                                        <?php } else { ?>
                                            <td style="vertical-align: top; text-align: left;"><?= $row['nik_ibu']; ?></td>
                                            <td style="vertical-align: top; text-align: left;"><?= $row['nama_ibu']; ?></td>
                                            <td style="vertical-align: top; text-align: left;">
                                                Tahun : <?= $row['tahun_lahir_ibu']; ?> <br>
                                                <?php 
                                                $tahun_lahir_ibu = $row['tahun_lahir_ibu']; 
                                                $tahun_sekarang = date("Y"); 
                                                $umur = $tahun_sekarang - $tahun_lahir_ibu; 
                                                echo "Umur : "; echo $umur; echo " Tahun"; 
                                                ?>
                                            </td>
                                            <td style="vertical-align: top; text-align: center;">
                                                <?php 
                                                $sql_barang = mysqli_query($con, "SELECT * FROM pendidikan WHERE id_pendidikan = '$row[id_pendidikan]'");
                                                while ($data_barang = mysqli_fetch_array($sql_barang)) { 
                                                    echo $data_barang['pendidikan']."<br>"; 
                                                } 
                                                ?>
                                            </td>
                                            <td style="vertical-align: top; text-align: center;">
                                                <?php 
                                                $sql_barang = mysqli_query($con, "SELECT * FROM pekerjaan WHERE id_pekerjaan = '$row[id_pekerjaan]'");
                                                while ($data_barang = mysqli_fetch_array($sql_barang)) { 
                                                    echo $data_barang['pekerjaan']."<br>"; 
                                                } 
                                                ?>
                                            </td>
                                            <td style="vertical-align: top; text-align: right;">Rp. <?php echo number_format($row['penghasilan_ibu'], 0, ',','.') ?>,-</td>
                                            <td style="vertical-align: top; text-align: center;">
                                                <?php 
                                                $sql_barang = mysqli_query($con, "SELECT * FROM khusus WHERE id_khusus = '$row[id_khusus]'");
                                                while ($data_barang = mysqli_fetch_array($sql_barang)) { 
                                                    echo $data_barang['khusus']."<br>"; 
                                                } 
                                                ?>
                                            </td>
                                        <?php } ?>
                                        <td style="vertical-align: top; text-align: center;">
                                            <?php if (!empty($row['id_ibu'])): ?>
                                                <div class="dropdown">
                                                    <button class="btn btn-warning dropdown-toggle btn-sm" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                                        <i class="fa-regular fa-cogs"></i>
                                                    </button>
                                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton"> 
                                                        <li><a class="dropdown-item" href="?page=siswa&aksi=ibu_ubah&nisn=<?= $row['nisn'] ?>&id_ibu=<?= $row['id_ibu'] ?>">Ubah</a></li>
                                                        <li><a class="dropdown-item" href="javascript:void(0)" onclick="confirmDelete(<?= $row['id_ibu']; ?>)">Hapus</a></li>
                                                    </ul>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php 
                                $nomor++; 
                                } ?>
                            </tbody>
                        </table>
                    </div>
                </div> 
            </div>
        </div>
    </div>
</div> 

<script>
function confirmDelete(id_ibu) {
    Swal.fire({
        title: 'Apakah Anda yakin?',
        text: "Anda tidak bisa mengembalikan data yang telah dihapus!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = "?page=siswa&aksi=ibu_hapus&id_ibu=" + id_ibu;
        }
    });
}
</script> 

