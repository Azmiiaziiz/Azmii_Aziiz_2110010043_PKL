    
<?php
$nisn = $_GET['nisn'];
$id_ayah = $_GET['id_ayah'];
$sql = $con->query("SELECT siswa.nisn, 
                           siswa.nama AS nama_siswa, 
                           ayah.id_ayah, 
                           ayah.nik_ayah, 
                           ayah.nama_ayah, 
                           ayah.tahun_lahir_ayah, 
                           ayah.id_pendidikan, 
                           ayah.id_pekerjaan, 
                           ayah.penghasilan_ayah, 
                           ayah.id_khusus
                           FROM siswa
                           LEFT JOIN ayah ON siswa.nisn = ayah.nisn WHERE siswa.nisn='$nisn' AND ayah.id_ayah='$id_ayah'");
$row = mysqli_fetch_assoc($sql);
?>

<div class="row">
    <div class="col-12">
        <div class="panel">
            <div class="panel-header">
                <h5>Wali Siswa (Ayah)
                </h5>
            </div>
            <div class="panel-body">    
                <div class="card mb-20">
                    <div class="card-header">Tambah Data Wali Siswa (Ayah) 
                        <strong>
                            <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; "NISN Siswa : <?= $row['nisn'] ?>"
                            <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; "Nama Siswa : <?= $row['nama_siswa'] ?>"
                        </strong>
                    </div>
                    <div class="card-body">
                        <form method="post" enctype="multipart/form-data">
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">NISN Siswa</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="nisn" value="<?= $row['nisn'] ?>" readonly required>
                                </div>
                            </div> 
                            <div class="row mb-4">
                                <label class="col-sm-3 col-form-label">Nama Siswa</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="nama" value="<?= $row['nama_siswa'] ?>" readonly required>
                                </div>
                            </div>

                            <div class="profile-edit-tab-title">
                                <h6><strong>Informasi Wali Siswa (Ayah)</strong></h6>
                            </div> 

                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">NIK</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="nik_ayah" value="<?= $row['nik_ayah'] ?>" required>
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Nama</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="nama_ayah" value="<?= $row['nama_ayah'] ?>" required>
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Tahun Lahir</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="tahun_lahir_ayah" value="<?= $row['tahun_lahir_ayah'] ?>" required>
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Pendidikan</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="id_pendidikan" required>
                                        <option selected disabled>Pilih</option>
                                        <?php
                                        $sql = mysqli_query($con, "SELECT * FROM pendidikan");
                                        while ($kar = mysqli_fetch_array($sql)) {
                                            $selected = ($row['id_pendidikan'] == $kar['id_pendidikan']) ? 'selected' : '';
                                            echo "<option value='$kar[id_pendidikan]' $selected>$kar[pendidikan]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div>  
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Pekerjaan</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="id_pekerjaan" required>
                                        <option selected disabled>Pilih</option>
                                        <?php
                                        $sql = mysqli_query($con, "SELECT * FROM pekerjaan");
                                        while ($kar = mysqli_fetch_array($sql)) {
                                            $selected = ($row['id_pekerjaan'] == $kar['id_pekerjaan']) ? 'selected' : '';
                                            echo "<option value='$kar[id_pekerjaan]' $selected>$kar[pekerjaan]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div>   
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Penghasilan</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="penghasilan_ayah" id="penghasilan_ayah" value="<?php echo number_format($row['penghasilan_ayah'], 0, ',','.') ?>" onkeypress="return angka(event);" required>
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Berkebutuhan Khusus</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="id_khusus" required>
                                        <option selected disabled>Pilih</option>
                                        <?php
                                        $sql = mysqli_query($con, "SELECT * FROM khusus");
                                        while ($kar = mysqli_fetch_array($sql)) {
                                            $selected = ($row['id_khusus'] == $kar['id_khusus']) ? 'selected' : '';
                                            echo "<option value='$kar[id_khusus]' $selected>$kar[khusus]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div>    
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">&nbsp;</label>
                                <div class="col-sm-9">
                                	<button type="submit" name="tambah" class="btn btn-primary btn-sm">Simpan</button>
                                	<a href="?page=siswa&aksi=ayah" class="btn btn-danger btn-sm">Kembali</a>
                                </div>
                            </div> 
                        </form>
                        <?php  
                        if (isset($_POST['tambah'])) {
                            $nisn = $_POST['nisn'];
                            $nama_ayah = $_POST['nama_ayah'];
                            $nik_ayah = $_POST['nik_ayah'];
                            $tahun_lahir_ayah = $_POST['tahun_lahir_ayah'];
                            $id_pendidikan = $_POST['id_pendidikan'];
                            $id_pekerjaan = $_POST['id_pekerjaan'];
                            $penghasilan1         = $_POST['penghasilan_ayah'];
                            $penghasilan_ayah          = str_replace(".", "", $penghasilan1);
                            $id_khusus = $_POST['id_khusus'];
                         
                            $query = "UPDATE ayah SET 
                                        nama_ayah='$nama_ayah', 
                                        nik_ayah='$nik_ayah', 
                                        tahun_lahir_ayah='$tahun_lahir_ayah', 
                                        id_pendidikan='$id_pendidikan', 
                                        id_pekerjaan='$id_pekerjaan', 
                                        penghasilan_ayah='$penghasilan_ayah', 
                                        id_khusus='$id_khusus' 
                                      WHERE id_ayah='$id_ayah' AND nisn='$nisn'";

                            if ($con->query($query) === TRUE) {
                                echo "<script>
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Berhasil!',
                                            text: 'Data berhasil diperbarui.',
                                            confirmButtonText: 'OK'
                                        }).then((result) => {
                                            if (result.isConfirmed) {
                                                window.location.href = '?page=siswa&aksi=ayah';
                                            }
                                        });
                                      </script>";
                            } else {
                                echo "<script>
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Gagal!',
                                            text: 'Terjadi kesalahan saat memperbarui data.',
                                            confirmButtonText: 'OK'
                                        });
                                      </script>";
                            }
                        }
                        ?>
                    </div>
                </div> 
            </div>
        </div>
    </div>
</div>  

<script type="text/javascript">
    function angka(evt) 
    {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57)) 
        {
            return false;
        }
        return true;
    }
</script>


<script type="text/javascript">

    var penghasilan_ayah = document.getElementById('penghasilan_ayah');
    penghasilan_ayah.addEventListener('keyup', function(e)
    {
        penghasilan_ayah.value = formatRupiah(this.value);
    }); 
    
    /* Fungsi */
    function formatRupiah(angka, prefix)
    {
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split    = number_string.split(','),
            sisa     = split[0].length % 3,
            rupiah     = split[0].substr(0, sisa),
            ribuan     = split[0].substr(sisa).match(/\d{3}/gi);
            
        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }
        
        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    } 

</script> 