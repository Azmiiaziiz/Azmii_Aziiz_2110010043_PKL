<?php
$nisn = $_GET['nisn'];
$ambil = $con->query("SELECT * FROM siswa NATURAL JOIN agama NATURAL JOIN khusus NATURAL JOIN transportasi NATURAL JOIN kelayakan WHERE nisn='$nisn'");
$row = $ambil->fetch_assoc();
?>
                    
<div class="row">
    <div class="col-12">
        <div class="panel">
            <div class="panel-header">
                <h5>Siswa</h5>
            </div>
            <div class="panel-body">  
                <div class="card mb-20">
                    <div class="card-header">
                        Data Siswa 
                        <strong>
                            <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; "NISN Siswa : <?= $row['nisn'] ?>"
                            <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; "Nama Siswa : <?= $row['nama'] ?>"
                        </strong>
                    </div>
                    <div class="card-body">
                        
                        <div class="panel">
                            <div class="btn-box d-flex flex-wrap gap-1" id="nav-tab" role="tablist">
                                <button class="btn btn-sm btn-outline-primary active" id="nav-edit-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-edit-profile" type="button" role="tab" aria-controls="nav-edit-profile" aria-selected="true">Profil Siswa</button>
                                <button class="btn btn-sm btn-outline-primary" id="nav-change-password-tab" data-bs-toggle="tab" data-bs-target="#nav-change-password" type="button" role="tab" aria-controls="nav-change-password" aria-selected="false">Data Ayah dan Ibu</button>

                                <?php 
                                // Cek apakah penerima_kip adalah "Ya"
                                if (isset($row['penerima_kip']) && $row['penerima_kip'] == 'Ya') { 
                                    // Jika Ya, tampilkan tombol KIP
                                    echo '<button class="btn btn-sm btn-outline-primary" id="nav-other-settings-tab" data-bs-toggle="tab" data-bs-target="#nav-other-settings" type="button" role="tab" aria-controls="nav-other-settings" aria-selected="false">KIP</button>';
                                } elseif (isset($row['penerima_kip']) && $row['penerima_kip'] == 'Tidak') { 
                                    // Jika Tidak, sembunyikan tombol KIP dan tampilkan pesan
                                    echo '<small class="alert alert-danger">Siswa ini bukan penerima KIP.</small>';
                                }
                                ?>
                            </div>
                            <div class="panel-body">
                                <div class="tab-content profile-edit-tab" id="nav-tabContent">
                                    <div class="tab-pane fade show active" id="nav-edit-profile" role="tabpanel" aria-labelledby="nav-edit-profile-tab" tabindex="0">
                                        <form>
                                            <div class="profile-edit-tab-title">
                                                <h6>Siswa Informasi</h6>
                                            </div>
                                            <div class="public-information mb-25">
                                                <div class="row g-4">
                                                    <div class="col-md-3">
                                                        <div class="admin-profile">
                                                            <div class="image-wrap">
                                                                <div class="part-img rounded-circle overflow-hidden">
                                                                    <img src="images/user.png" class="img-thumbnail" style="border: 2px solid #007bff; border-radius: 8px;" alt="admin">
                                                                </div> 
                                                            </div>
                                                            <span class="admin-name"><?= $row['nisn']; ?></span>
                                                            <span class="admin-role"><?= $row['nama']; ?></span>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <div class="row g-3">
                                                            <div class="col-sm-6">
                                                                <div class="input-group">
                                                                    <span class="input-group-text"><i class="fa-light fa-user"></i></span>
                                                                    <input type="text" class="form-control" required value="<?= $row['nisn']; ?>" readonly>
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-6">
                                                                <div class="input-group">
                                                                    <span class="input-group-text"><i class="fa-light fa-user"></i></span>
                                                                    <input type="text" class="form-control" required value="<?= $row['nama']; ?>" readonly>
                                                                </div>
                                                            </div> 
                                                            <div class="col-12">
                                                                <input type="text" class="form-control h-150-p" required value="<?= $row['alamat']; ?>, RT <?= $row['rt']; ?>, RW <?= $row['rw']; ?>, Kodepos <?= $row['kodepos']; ?>" style="vertical-align: top;" readonly> 
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="container private-information mb-4"> 
                                                <div class="table-responsive">
                                                    <table class="table table-striped table-bordered table-hover">
                                                        <tbody>
                                                            <tr>
                                                                <th style="width: 30%;">NISN</th>
                                                                <td style="text-align: left;"><?= $row['nisn'] ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Nama</th>
                                                                <td style="text-align: left;"><?= $row['nama'] ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Kelas</th>
                                                                <td style="text-align: left;">
                                                                    <?php 
                                                                    $sql_barang = mysqli_query($con, "SELECT * FROM kelas WHERE id_kelas = '$row[id_kelas]' ");
                                                                        while ($data_barang = mysqli_fetch_array($sql_barang)){
                                                                        echo "$data_barang[kelas]";
                                                                    } 
                                                                    ?>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th>Rombongan Belajar</th>
                                                                <td style="text-align: left;">
                                                                    <?php 
                                                                    $sql_barang = mysqli_query($con, "SELECT * FROM rombel WHERE id_rombel = '$row[id_rombel]' ");
                                                                        while ($data_barang = mysqli_fetch_array($sql_barang)){
                                                                        echo "$data_barang[rombel]";
                                                                    } 
                                                                    ?>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th>Jenis Kelamin</th>
                                                                <td style="text-align: left;"><?= $row['jk'] == 'L' ? 'Laki-Laki' : 'Perempuan' ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Tempat, Tanggal Lahir</th>
                                                                <td style="text-align: left;"><?= $row['tmp'] ?>, <?= date('d-m-Y', strtotime($row['tgl'])) ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>No. Kartu Keluarga</th>
                                                                <td style="text-align: left;"><?= $row['no_kk'] ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Agama</th>
                                                                <td style="text-align: left;"><?= $row['agama'] ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Kebutuhan Khusus</th>
                                                                <td style="text-align: left;"><?= $row['khusus'] ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Alamat Lengkap</th>
                                                                <td style="text-align: left;"><?= $row['alamat'] ?>, RT <?= $row['rt'] ?>/ RW <?= $row['rw'] ?>, <?php 
                                                                    $sql_barang = mysqli_query($con, "SELECT * FROM siswa 
                                                                        JOIN wilayah_2022 ON siswa.desa=wilayah_2022.kode WHERE nisn = '$row[nisn]' OR CHAR_LENGTH(kode)='$row[desa]' ");
                                                                        while ($data_barang = mysqli_fetch_array($sql_barang)){
                                                                        echo "$data_barang[nama]";
                                                                    } 
                                                                    ?>, <?php 
                                                                    $sql_barang = mysqli_query($con, "SELECT * FROM siswa 
                                                                        JOIN wilayah_2022 ON siswa.kecamatan=wilayah_2022.kode WHERE nisn = '$row[nisn]' OR CHAR_LENGTH(kode)='$row[kecamatan]' ");
                                                                        while ($data_barang = mysqli_fetch_array($sql_barang)){
                                                                        echo "$data_barang[nama]";
                                                                    } 
                                                                    ?>, <?php 
                                                                    $sql_barang = mysqli_query($con, "SELECT * FROM siswa 
                                                                        JOIN wilayah_2022 ON siswa.kabupaten=wilayah_2022.kode WHERE nisn = '$row[nisn]' OR CHAR_LENGTH(kode)='$row[kabupaten]' ");
                                                                        while ($data_barang = mysqli_fetch_array($sql_barang)){
                                                                        echo "$data_barang[nama]";
                                                                    } 
                                                                    ?>, <?php 
                                                                    $sql_barang = mysqli_query($con, "SELECT * FROM siswa 
                                                                        JOIN wilayah_2022 ON siswa.provinsi=wilayah_2022.kode WHERE nisn = '$row[nisn]' OR CHAR_LENGTH(kode)='$row[provinsi]' ");
                                                                        while ($data_barang = mysqli_fetch_array($sql_barang)){
                                                                        echo "$data_barang[nama]";
                                                                    } 
                                                                    ?>, <?= $row['kodepos'] ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Provinsi</th>
                                                                <td style="text-align: left; text-transform: capitalize;">
                                                                    <?php 
                                                                    $sql_barang = mysqli_query($con, "SELECT * FROM siswa 
                                                                        JOIN wilayah_2022 ON siswa.provinsi=wilayah_2022.kode WHERE nisn = '$row[nisn]' OR CHAR_LENGTH(kode)='$row[provinsi]' ");
                                                                        while ($data_barang = mysqli_fetch_array($sql_barang)){
                                                                        echo "$data_barang[nama]";
                                                                    } 
                                                                    ?>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th>Kabupaten / Kota</th>
                                                                <td style="text-align: left; text-transform: capitalize;">
                                                                    <?php 
                                                                    $sql_barang = mysqli_query($con, "SELECT * FROM siswa 
                                                                        JOIN wilayah_2022 ON siswa.kabupaten=wilayah_2022.kode WHERE nisn = '$row[nisn]' OR CHAR_LENGTH(kode)='$row[kabupaten]' ");
                                                                        while ($data_barang = mysqli_fetch_array($sql_barang)){
                                                                        echo "$data_barang[nama]";
                                                                    } 
                                                                    ?>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th>Kecamatan</th>
                                                                <td style="text-align: left; text-transform: capitalize;">
                                                                    <?php 
                                                                    $sql_barang = mysqli_query($con, "SELECT * FROM siswa 
                                                                        JOIN wilayah_2022 ON siswa.kecamatan=wilayah_2022.kode WHERE nisn = '$row[nisn]' OR CHAR_LENGTH(kode)='$row[kecamatan]' ");
                                                                        while ($data_barang = mysqli_fetch_array($sql_barang)){
                                                                        echo "$data_barang[nama]";
                                                                    } 
                                                                    ?>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th>Kelurahan / Desa</th>
                                                                <td style="text-align: left; text-transform: capitalize;">
                                                                    <?php 
                                                                    $sql_barang = mysqli_query($con, "SELECT * FROM siswa 
                                                                        JOIN wilayah_2022 ON siswa.desa=wilayah_2022.kode WHERE nisn = '$row[nisn]' OR CHAR_LENGTH(kode)='$row[desa]' ");
                                                                        while ($data_barang = mysqli_fetch_array($sql_barang)){
                                                                        echo "$data_barang[nama]";
                                                                    } 
                                                                    ?>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th>Tinggal Bersama</th>
                                                                <td style="text-align: left;"><?= $row['tinggal_bersama'] ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Transportasi</th>
                                                                <td style="text-align: left;"><?= $row['transportasi'] ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Anak Ke</th>
                                                                <td style="text-align: left;"><?= $row['anak_ke'] ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Penerima KPS</th>
                                                                <td style="text-align: left; vertical-align: top;">
                                                                    Terima : <?= $row['penerima_kps']; ?>
                                                                    <?php if ($row['penerima_kps'] === 'Ya'): ?>
                                                                        <br> No : <?= $row['no_kps']; ?>
                                                                    <?php endif; ?>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th>Kelayakan</th>
                                                                <td style="text-align: left;"><?= $row['kelayakan'] ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Penerima KIP</th>
                                                                <td style="text-align: left; vertical-align: top;">
                                                                    Terima : <?= $row['penerima_kip']; ?>
                                                                    <?php if ($row['penerima_kip'] === 'Ya'): ?>
                                                                        <br> No kartu : <?= $row['no_kip']; ?> 
                                                                        <br> Atas Nama : <?= $row['nama_tertera']; ?> 
                                                                        <br> Terima Kartu : <?= $row['terima_kartu']; ?>
                                                                    <?php endif; ?> 
                                                                </td>
                                                            </tr> 
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </form>
                                    </div>

                                    <?php  
                                    function hitung_umur($tahun_lahir) {
                                        return date('Y') - $tahun_lahir;
                                    }

                                    $sql_data = mysqli_query($con, "
                                        SELECT 
                                            ayah.*, 
                                            ibu.*, 
                                            pekerjaan_ayah.pekerjaan AS pekerjaan_ayah, 
                                            pekerjaan_ibu.pekerjaan AS pekerjaan_ibu, 
                                            khusus_ayah.khusus AS khusus_ayah, 
                                            khusus_ibu.khusus AS khusus_ibu, 
                                            pendidikan_ayah.pendidikan AS pendidikan_ayah, 
                                            pendidikan_ibu.pendidikan AS pendidikan_ibu
                                        FROM siswa
                                        LEFT JOIN ayah ON ayah.nisn = siswa.nisn
                                        LEFT JOIN pekerjaan AS pekerjaan_ayah ON pekerjaan_ayah.id_pekerjaan = ayah.id_pekerjaan
                                        LEFT JOIN khusus AS khusus_ayah ON khusus_ayah.id_khusus = ayah.id_khusus
                                        LEFT JOIN pendidikan AS pendidikan_ayah ON pendidikan_ayah.id_pendidikan = ayah.id_pendidikan
                                        LEFT JOIN ibu ON ibu.nisn = siswa.nisn
                                        LEFT JOIN pekerjaan AS pekerjaan_ibu ON pekerjaan_ibu.id_pekerjaan = ibu.id_pekerjaan
                                        LEFT JOIN khusus AS khusus_ibu ON khusus_ibu.id_khusus = ibu.id_khusus
                                        LEFT JOIN pendidikan AS pendidikan_ibu ON pendidikan_ibu.id_pendidikan = ibu.id_pendidikan
                                        WHERE siswa.nisn = '$nisn'
                                    ");

                                    $row_data = mysqli_fetch_assoc($sql_data);
 
                                    $ayah_exists = !empty($row_data['nik_ayah']);
                                    $ibu_exists = !empty($row_data['nik_ibu']);
                                    ?>

                                    <div class="tab-pane fade" id="nav-change-password" role="tabpanel" aria-labelledby="nav-change-password-tab" tabindex="0">
                                        <div class="row"> 
                                            <div class="col-sm-6">
                                                <div class="profile-edit-tab-title">
                                                    <h6>Data Wali Siswa Ayah "<?= $row['nama']; ?>"</h6>
                                                </div>
                                                <div class="social-information">
                                                    <?php if (!$ayah_exists): ?>
                                                        <p>
                                                            <a href="?page=siswa&aksi=ayah_tambah&nisn=<?= $row['nisn'] ?>" class="btn btn-primary btn-sm">Tambah Data Ayah</a>
                                                        </p>
                                                        <div class="alert alert-warning" role="alert">Data ayah belum diinputkan. Silakan tambah data.</div>
                                                    <?php else: ?>
                                                        <div class="alert alert-success" role="alert">Data ayah sudah diinputkan.</div>
                                                        <div class="table-responsive">
                                                            <table class="table table-striped table-bordered table-hover">
                                                                <tbody>
                                                                    <tr><th style="font-weight: bold;">NIK</th><td><?= $row_data['nik_ayah']; ?></td></tr>
                                                                    <tr><th style="font-weight: bold;">Nama</th><td><?= $row_data['nama_ayah']; ?></td></tr>
                                                                    <tr><th style="font-weight: bold;">Tahun Lahir</th><td><?= $row_data['tahun_lahir_ayah']; ?></td></tr>
                                                                    <tr><th style="font-weight: bold;">Umur</th><td><?= hitung_umur($row_data['tahun_lahir_ayah']); ?> tahun</td></tr>
                                                                    <tr><th style="font-weight: bold;">Pendidikan</th><td><?= $row_data['pendidikan_ayah']; ?></td></tr>
                                                                    <tr><th style="font-weight: bold;">Pekerjaan</th><td><?= $row_data['pekerjaan_ayah']; ?></td></tr>
                                                                    <tr><th style="font-weight: bold;">Penghasilan</th><td><?= number_format($row_data['penghasilan_ayah'], 0, ',', '.'); ?></td></tr>
                                                                    <tr><th style="font-weight: bold;">Berkebutuhan Khusus</th><td><?= $row_data['khusus_ayah']; ?></td></tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>

                                            </div>

                                            <div class="col-sm-6"> 
                                                <div class="profile-edit-tab-title">
                                                    <h6>Data Wali Siswa Ibu "<?= $row['nama']; ?>"</h6>
                                                </div>
                                                <div class="social-information">
                                                    <?php if (!$ibu_exists): ?>
                                                        <p>
                                                            <a href="?page=siswa&aksi=ibu_tambah&nisn=<?= $row['nisn'] ?>" class="btn btn-primary btn-sm">Tambah Data Ibu</a>
                                                        </p>
                                                        <div class="alert alert-warning" role="alert">Data ibu belum diinputkan. Silakan tambah data.</div>
                                                    <?php else: ?>
                                                        <div class="alert alert-success" role="alert">Data ibu sudah diinputkan.</div>
                                                        <div class="table-responsive">
                                                            <table class="table table-striped table-bordered table-hover">
                                                                <tbody>
                                                                    <tr><th style="font-weight: bold;">NIK</th><td><?= $row_data['nik_ibu']; ?></td></tr>
                                                                    <tr><th style="font-weight: bold;">Nama</th><td><?= $row_data['nama_ibu']; ?></td></tr>
                                                                    <tr><th style="font-weight: bold;">Tahun Lahir</th><td><?= $row_data['tahun_lahir_ibu']; ?></td></tr>
                                                                    <tr><th style="font-weight: bold;">Umur</th><td><?= hitung_umur($row_data['tahun_lahir_ibu']); ?> tahun</td></tr>
                                                                    <tr><th style="font-weight: bold;">Pendidikan</th><td><?= $row_data['pendidikan_ibu']; ?></td></tr>
                                                                    <tr><th style="font-weight: bold;">Pekerjaan</th><td><?= $row_data['pekerjaan_ibu']; ?></td></tr>
                                                                    <tr><th style="font-weight: bold;">Penghasilan</th><td><?= number_format($row_data['penghasilan_ibu'], 0, ',', '.'); ?></td></tr>
                                                                    <tr><th style="font-weight: bold;">Berkebutuhan Khusus</th><td><?= $row_data['khusus_ibu']; ?></td></tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>   
                                        </div> 
                                    </div>

                                    <div class="tab-pane fade" id="nav-other-settings" role="tabpanel" aria-labelledby="nav-other-settings-tab" tabindex="0">
                                        <div class="row">
                                            <?php  
                                            $ambil = $con->query("SELECT * 
                                                                  FROM tahap 
                                                                  JOIN pencairan ON tahap.id_pencairan = pencairan.id_pencairan 
                                                                  JOIN siswa ON pencairan.nisn = siswa.nisn 
                                                                  WHERE siswa.nisn = '$nisn' 
                                                                  ORDER BY tahap.id_tahap ASC");

                                            while ($rows = $ambil->fetch_assoc()) { 
                                                $tgl = tgl_indo($rows['tglsk']);  
 
                                                if (trim($rows['penerima_kip']) == 'Tidak') {
                                                    echo '<div class="alert alert-danger" role="alert">
                                                            Siswa ini bukan penerima KIP.
                                                          </div>';
                                                    continue;  
                                                }
 
                                                if (trim($rows['penerima_kip']) == 'Ya') { 
                                                    ?>
                                                    <div class="col-sm-6">
                                                        <div class="profile-edit-tab-title">
                                                            <h6>Informasi KIP Siswa</h6>
                                                        </div>
                                                        <div class="activity-email-settings">
                                                            <table class="table table-striped table-bordered table-hover"> 
                                                                <tbody>
                                                                    <?php if ($rows['status_tahap'] !== 'SK Pemberian' && $rows['status_tahap'] !== 'Terdaftar'): ?>
                                                                        <tr>
                                                                            <th style="width: 30%;">Bank</th>
                                                                            <td style="text-align: left;">
                                                                                <?php 
                                                                                $sql_barang = mysqli_query($con, "SELECT * FROM bank WHERE id_bank = '$rows[id_bank]'");
                                                                                while ($data_barang = mysqli_fetch_array($sql_barang)){
                                                                                    echo "$data_barang[bank]";
                                                                                } 
                                                                                ?>
                                                                            </td>
                                                                        </tr> 
                                                                        <tr>
                                                                            <th style="width: 30%;">No Rekening / No Virtual</th>
                                                                            <td style="text-align: left;"><?= $rows['norek'] ?></td>
                                                                        </tr> 
                                                                        <tr>
                                                                            <th style="width: 30%;">Nominal</th>
                                                                            <td style="text-align: left;"><?= number_format($rows['nominal_tahap'], 0, ',','.') ?></td>
                                                                        </tr> 
                                                                        <tr>
                                                                            <th style="width: 30%;">Nomor SK</th>
                                                                            <td style="text-align: left;"><?= $rows['nosk'] ?></td>
                                                                        </tr> 
                                                                        <tr>
                                                                            <th style="width: 30%;">Tanggal SK</th>
                                                                            <td style="text-align: left;"><?= $tgl ?></td>
                                                                        </tr> 
                                                                    <?php endif; ?>
                                                                    <tr>
                                                                        <th style="width: 30%;">Pengusul</th>
                                                                        <td style="text-align: left;"><?= $rows['pengusul'] ?></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th style="width: 30%;">Keterangan</th>
                                                                        <td style="text-align: left;"><?= $rows['ket'] ?></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th style="width: 30%;">Status</th>
                                                                        <td style="text-align: left;"><?= $rows['status_tahap'] ?></td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                    <?php 
                                                }
                                            } 
                                        ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div> 
            </div>
        </div>
    </div>
</div>  