<div class="row">
    <div class="col-12">
        <div class="panel">
            <div class="panel-header">
                <h5>Siswa</h5>
            </div>
            <div class="panel-body">    
                <div class="card mb-20">
                    <div class="card-header">Tambah Data Siswa</div>
                    <div class="card-body">
                        <form method="post" enctype="multipart/form-data">
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">NISN</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="nisn" required>
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Nama</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="nama" required>
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Kelas</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="id_kelas" required>
                                        <option selected disabled>Pilih</option>
                                        <?php
                                        $sql = mysqli_query($con, "SELECT * FROM kelas ");
                                        while ($kar = mysqli_fetch_array($sql))
                                        {
                                            echo "<option value='$kar[id_kelas]'>$kar[kelas]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div>  
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Rombongan Belajar</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="id_rombel" required>
                                        <option selected disabled>Pilih</option>
                                        <?php
                                        $sql = mysqli_query($con, "SELECT * FROM rombel ");
                                        while ($kar = mysqli_fetch_array($sql))
                                        {
                                            echo "<option value='$kar[id_rombel]'>$kar[rombel]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div>  
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Jenis Kelamin</label>
                                <div class="col-sm-9">
                                    <select name="jk" class="form-control">
                                        <option selected disabled>Pilih</option>
                                        <option value="Laki-Laki">Laki-Laki</option>
                                        <option value="Perempuan">Perempuan</option>
                                    </select>
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Tempat Lahir</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="tmp" required>
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Tanggal Lahir</label>
                                <div class="col-sm-9">
                                    <input type="date" class="form-control" name="tgl" required>
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">No Kartu Keluarga</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="no_kk" required>
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Agama</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="id_agama" required>
                                        <option selected disabled>Pilih</option>
                                        <?php
                                        $sql = mysqli_query($con, "SELECT * FROM agama ");
                                        while ($kar = mysqli_fetch_array($sql))
                                        {
                                            echo "<option value='$kar[id_agama]'>$kar[agama]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div>  
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Bekebutuhan Khusus</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="id_khusus" required>
                                        <option selected disabled>Pilih</option>
                                        <?php
                                        $sql = mysqli_query($con, "SELECT * FROM khusus ");
                                        while ($kar = mysqli_fetch_array($sql))
                                        {
                                            echo "<option value='$kar[id_khusus]'>$kar[khusus]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Alamat</label>
                                <div class="col-sm-9">
                                    <div class="input-group mb-3">
                                        <input type="text" class="form-control" name="alamat" placeholder="Alamat" required>
                                        <div class="input-group-append">
                                            <input type="text" class="form-control" name="rt" placeholder="RT" required>
                                            <input type="text" class="form-control" name="rw" placeholder="RW" required>
                                        </div>
                                    </div>
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Provinsi</label>
                                <div class="col-sm-9"> 
                                    <select class="form-control mb-2" required name="provinsi" id="form_prov">
                                        <option>Pilih Provinsi</option>
                                        <?php 
                                        $daerah = mysqli_query($con,"SELECT kode,nama FROM wilayah_2022 WHERE CHAR_LENGTH(kode)=2 ORDER BY nama");
                                        while($d = mysqli_fetch_array($daerah)){
                                            ?>
                                            <option value="<?php echo $d['kode']; ?>"><?php echo $d['nama']; ?></option>
                                            <?php 
                                        }
                                        ?>
                                    </select> 

                                    <select class="form-control mb-2" required name="kabupaten" id="form_kab"></select>  

                                    <select class="form-control mb-2" required name="kecamatan" id="form_kec"></select> 

                                    <select class="form-control" required name="desa" id="form_des"></select> 
                                </div>
                            </div>
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Kode POS</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="kodepos" required>
                                </div>
                            </div>  
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Tempat Tinggal</label>
                                <div class="col-sm-9">
                                    <select name="tinggal_bersama" class="form-control">
                                        <option selected disabled>Pilih</option>
                                        <option value="Bersama orang tua">Bersama orang tua</option>
                                        <option value="Wali">Wali</option>
                                        <option value="Kos">Kos</option>
                                        <option value="Asrama">Asrama</option>
                                        <option value="Panti Asuhan">Panti Asuhan</option>
                                        <option value="Pesantren">Pesantren</option>
                                        <option value="Lainnya">Lainnya</option>
                                    </select>
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Transportasi</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="id_transportasi" required>
                                        <option selected disabled>Pilih</option>
                                        <?php
                                        $sql = mysqli_query($con, "SELECT * FROM transportasi ");
                                        while ($kar = mysqli_fetch_array($sql))
                                        {
                                            echo "<option value='$kar[id_transportasi]'>$kar[transportasi]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Anak Ke</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="anak_ke" required>
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Penerima KPS</label>
                                <div class="col-sm-9">
                                    <select name="penerima_kps" class="form-control mb-2" id="penerima_kps" onchange="toggleNoKPS()" required>
                                        <option selected disabled>Pilih</option>
                                        <option value="Ya">Ya</option>
                                        <option value="Tidak">Tidak</option>
                                    </select>
                                    <input type="text" class="form-control mb-2" name="no_kps" id="no_kps_row" style="display: none;" placeholder="Nomor Penerima KPS">
                                </div>
                            </div>  
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Alasan Layak KIP</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="id_kelayakan" required>
                                        <option selected disabled>Pilih</option>
                                        <?php
                                        $sql = mysqli_query($con, "SELECT * FROM kelayakan ");
                                        while ($kar = mysqli_fetch_array($sql))
                                        {
                                            echo "<option value='$kar[id_kelayakan]'>$kar[kelayakan]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div> 

                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Penerima KIP</label>
                                <div class="col-sm-9">
                                    <select name="penerima_kip" class="form-control mb-2" required id="penerima_kip" onchange="toggleKIPDetails()">
                                        <option selected disabled>Pilih</option>
                                        <option value="Ya">Ya</option>
                                        <option value="Tidak">Tidak</option>
                                    </select> 

                                    <input type="text" class="form-control mb-2" name="no_kip" id="no_kip" placeholder="Masukkan Nomor KIP" style="display: none;">
                                    <input type="text" class="form-control mb-2" name="nama_tertera" id="nama_tertera" placeholder="Masukkan Nama Tertera" style="display: none;">
                                    <input type="text" class="form-control mb-2" name="terima_kartu" id="terima_kartu" placeholder="Masukkan Terima Kartu" style="display: none;">
                                </div>
                            </div>  
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">&nbsp;</label>
                                <div class="col-sm-9">
                                	<button type="submit" name="tambah" class="btn btn-primary btn-sm">Simpan</button>
                                	<a href="?page=siswa" class="btn btn-danger btn-sm">Kembali</a>
                                </div>
                            </div> 
                        </form>
                        <?php  
                         
                        if (isset($_POST['tambah'])) { 
                            $nisn = mysqli_real_escape_string($con, $_POST['nisn']);
                            $nama = mysqli_real_escape_string($con, $_POST['nama']);
                            $jk = mysqli_real_escape_string($con, $_POST['jk']);
                            $tmp = mysqli_real_escape_string($con, $_POST['tmp']);
                            $tgl = mysqli_real_escape_string($con, $_POST['tgl']);
                            $no_kk = mysqli_real_escape_string($con, $_POST['no_kk']);
                            $id_agama = mysqli_real_escape_string($con, $_POST['id_agama']);
                            $id_khusus = mysqli_real_escape_string($con, $_POST['id_khusus']);
                            $alamat = mysqli_real_escape_string($con, $_POST['alamat']);
                            $rt = mysqli_real_escape_string($con, $_POST['rt']);
                            $rw = mysqli_real_escape_string($con, $_POST['rw']);
                            $provinsi = mysqli_real_escape_string($con, $_POST['provinsi']);
                            $kabupaten = mysqli_real_escape_string($con, $_POST['kabupaten']);
                            $kecamatan = mysqli_real_escape_string($con, $_POST['kecamatan']);
                            $desa = mysqli_real_escape_string($con, $_POST['desa']);
                            $kodepos = mysqli_real_escape_string($con, $_POST['kodepos']);
                            $tinggal_bersama = mysqli_real_escape_string($con, $_POST['tinggal_bersama']);
                            $id_transportasi = mysqli_real_escape_string($con, $_POST['id_transportasi']);
                            $anak_ke = mysqli_real_escape_string($con, $_POST['anak_ke']);
                            $penerima_kps = mysqli_real_escape_string($con, $_POST['penerima_kps']);
                            $no_kps = mysqli_real_escape_string($con, $_POST['no_kps']);
                            $id_kelayakan = mysqli_real_escape_string($con, $_POST['id_kelayakan']);
                            $penerima_kip = mysqli_real_escape_string($con, $_POST['penerima_kip']);
                            $no_kip = mysqli_real_escape_string($con, $_POST['no_kip']);
                            $nama_tertera = mysqli_real_escape_string($con, $_POST['nama_tertera']);
                            $terima_kartu = mysqli_real_escape_string($con, $_POST['terima_kartu']);
                            $id_kelas = mysqli_real_escape_string($con, $_POST['id_kelas']);
                            $id_rombel = mysqli_real_escape_string($con, $_POST['id_rombel']);
                         
                            $query = "INSERT INTO siswa (nisn, nama, jk, tmp, tgl, no_kk, id_agama, id_khusus, alamat, rt, rw, provinsi, kabupaten, kecamatan, desa, kodepos, tinggal_bersama, id_transportasi, anak_ke, penerima_kps, no_kps, id_kelayakan, penerima_kip, no_kip, nama_tertera, terima_kartu, id_kelas, id_rombel) 
                                      VALUES ('$nisn', '$nama', '$jk', '$tmp', '$tgl', '$no_kk', '$id_agama', '$id_khusus', '$alamat', '$rt', '$rw', '$provinsi', '$kabupaten', '$kecamatan', '$desa', '$kodepos', '$tinggal_bersama', '$id_transportasi', '$anak_ke', '$penerima_kps', '$no_kps', '$id_kelayakan', '$penerima_kip', '$no_kip', '$nama_tertera', '$terima_kartu', '$id_kelas', '$id_rombel')";

                            if ($con->query($query) === TRUE) {
                                echo "<script>
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Berhasil!',
                                            text: 'Data berhasil disimpan.',
                                            confirmButtonText: 'OK'
                                        }).then((result) => {
                                            if (result.isConfirmed) {
                                                window.location.href = '?page=siswa';
                                            }
                                        });
                                      </script>";
                            } else {
                                echo "<script>
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Gagal!',
                                            text: 'Terjadi kesalahan saat menyimpan data.',
                                            confirmButtonText: 'OK'
                                        });
                                      </script>";
                            }
                        }
                        ?>
                    </div>
                </div> 
            </div>
        </div>
    </div>
</div>  

<script>
    function toggleNoKPS() {
        var penerimaKPS = document.getElementById("penerima_kps").value;
        var noKPSRow = document.getElementById("no_kps_row");

        if (penerimaKPS === "Ya") {
            noKPSRow.style.display = "block";   
        } else {
            noKPSRow.style.display = "none";    
        }
    }
</script>

<script>
    function toggleKIPDetails() {
        var penerimaKIP = document.getElementById("penerima_kip").value;
         
        var noKIP = document.getElementById("no_kip");
        var namaTertera = document.getElementById("nama_tertera");
        var terimaKartu = document.getElementById("terima_kartu");
 
        if (penerimaKIP === "Ya") {
            noKIP.style.display = "block";
            namaTertera.style.display = "block";
            terimaKartu.style.display = "block";
        } else { 
            noKIP.style.display = "none";
            namaTertera.style.display = "none";
            terimaKartu.style.display = "none";
        }
    }
</script>