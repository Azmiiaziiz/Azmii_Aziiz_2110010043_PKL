<?php
$nama_dokumen = 'Laporan Rekap Data Pencairan Bantuan KIP';
define('_MPDF_PATH', 'mpdf/');
include(_MPDF_PATH . "mpdf.php");
$mpdf = new mPDF('utf-8', 'A4');
ob_start();
include "../../inc/koneksi.php";
include "../../inc/tanggal.php";
$status_tahap = isset($_GET['status_tahap']) ? $_GET['status_tahap'] : '';  
 
if (empty($status_tahap)) {
    echo "<script>alert('Filter belum dipilih. Silakan pilih terlebih dahulu.'); window.history.back();</script>";
    exit;
}
?>

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
    <title><?php echo $meta['instansi'] ?></title>
    <link rel="icon" type="image/png" href="../../images/<?=$meta['logo'] ?>">
    <link rel="icon" href="../../images/<?=$meta['logo'] ?>"> 
    <style>
        .horizontal_center
        {
            border-top: 2px solid black;
            height: 5px; 
        }
    </style>
</head>

<body>
    <table>
        <tr>
            <td>
                <img src="../../images/<?=$meta['logo'] ?>" width="12%" height="12%">
            </td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td align="center">
                <p style="font-size: 35px; text-transform: uppercase; line-height: 100px;"><b><?php echo $meta['instansi'] ?></b></p>
                <p style="font-size: 14px;">
                    Alamat : <?php echo $meta['alamat'] ?> <br>
                    Email : <?php echo $meta['email'] ?> | Telp : <?php echo $meta['telp'] ?>
                </p>
            </td>
        </tr>
    </table>

    <p class="horizontal_center"></p> 

    <p align="center"><b>Laporan Rekap Data Pencairan Bantuan KIP <br> <small>Filter Data Status <?php echo $status_tahap ?></small></b></p>

    <table style="width: 100%; border-collapse: collapse;">
        <tr>
            <td style="font-size: 10px; border: 1px solid #999; padding: 2px; font-weight: bold;" align="center">No.</td>
            <td style="font-size: 10px; border: 1px solid #999; padding: 2px; font-weight: bold;">Siswa</td>  
            <td style="font-size: 10px; border: 1px solid #999; padding: 2px; font-weight: bold;">SK</td>  
            <td style="font-size: 10px; border: 1px solid #999; padding: 2px; font-weight: bold;">Keterangan</td>  
            <td style="font-size: 10px; border: 1px solid #999; padding: 2px; font-weight: bold;">Status</td>   
            <td style="font-size: 10px; border: 1px solid #999; padding: 2px; font-weight: bold;" align="center">Bank</td>  
            <td style="font-size: 10px; border: 1px solid #999; padding: 2px; font-weight: bold;" align="center">No Rekening</td>  
            <td style="font-size: 10px; border: 1px solid #999; padding: 2px; font-weight: bold;" align="right">Nominal</td>   
        </tr> 
        <?php 
            $nomor = 1; 
            $gtotal = 0;
            $ambil = $con->query("SELECT * FROM tahap JOIN pencairan ON tahap.id_pencairan=pencairan.id_pencairan WHERE status_tahap='$status_tahap' ORDER BY id_tahap ASC"); 
            while ($rows = $ambil->fetch_assoc()) { 
            $tgl = tgl_indo($rows['tglsk']); ?>
                <tr>
                    <td style="font-size: 10px; border: 1px solid #999; padding: 2px; vertical-align: top;" align="center"><?= $nomor; ?></td>
                    <td style="font-size: 10px; border: 1px solid #999; padding: 2px; vertical-align: top;">NISN : 
                        <?php 
                        $sql_barang = mysqli_query($con, "SELECT * FROM siswa WHERE nisn = '$rows[nisn]'");
                        while ($data_barang = mysqli_fetch_array($sql_barang)){
                            echo "$data_barang[nisn]";
                        } 
                        ?> <br> 
                      Nama : 
                        <?php 
                        $sql_barang = mysqli_query($con, "SELECT * FROM siswa WHERE nisn = '$rows[nisn]'");
                        while ($data_barang = mysqli_fetch_array($sql_barang)){
                            echo "$data_barang[nama]";
                        } 
                        ?>
                    </td>  
                    <td style="font-size: 10px; border: 1px solid #999; padding: 2px; vertical-align: top;">No SK : <?= $rows['nosk']; ?> <br> Tanggal SK : <?= $tgl; ?></td> 
                    <td style="font-size: 10px; border: 1px solid #999; padding: 2px; vertical-align: top;"><?= $rows['ket']; ?> <br> Pengusul : <?= $rows['pengusul']; ?></td> 
                    <td style="font-size: 10px; border: 1px solid #999; padding: 2px; vertical-align: top;"><?= $rows['status_tahap']; ?></td>
                    <td style="font-size: 10px; border: 1px solid #999; padding: 2px; vertical-align: top;" align="center">
                        <?php 
                        $sql_barang = mysqli_query($con, "SELECT * FROM bank WHERE id_bank = '$rows[id_bank]'");
                        while ($data_barang = mysqli_fetch_array($sql_barang)){
                            echo "$data_barang[bank]";
                        } 
                        ?>
                    </td> 
                    <td style="font-size: 10px; border: 1px solid #999; padding: 2px; vertical-align: top;" align="center"><?= $rows['norek']; ?></td> 
                    <td style="font-size: 10px; border: 1px solid #999; padding: 2px; vertical-align: top;" align="right"><?= number_format($rows['nominal_tahap'], 0, ',','.') ?></td>   

                </tr>
            <?php 
            $nomor++; 
            $gtotal += $rows['nominal_tahap'];  } ?>
            <tr>
                <th colspan="7" style="font-size: 10px; border: 1px solid #999; padding: 2px; font-weight: bold; text-align: center;">Total</th>
                <th  style="font-size: 10px; border: 1px solid #999; padding: 2px; text-align: right;"><?php echo number_format($gtotal, 0, ',', '.'); ?></th>  
            </tr>
    </table> 

    <table align="right" style="margin-top: 20px;">
        <tr>
            <th style="font-size: 12px">Banjarbaru, <?php echo tgl_indo(date('Y-m-d')); ?></th>
        </tr>
        <tr>
            <th style="font-size: 12px">Mengetahui <br>Kepala Sekolah</th>
        </tr>
        <tr>
            <th>&nbsp;</th>
        </tr>
        <tr>
            <th>&nbsp;</th>
        </tr>
        <tr>
            <th align="center" style="font-size: 12px"><u><?php echo $meta['pimpinan'] ?></u></th>
        </tr>
    </table>
    <br />
</body>

<?php
$html = ob_get_contents();  
ob_end_clean();
$mpdf->WriteHTML(utf8_encode($html));
$mpdf->Output($nama_dokumen . ".pdf", 'I');
exit;
?>
