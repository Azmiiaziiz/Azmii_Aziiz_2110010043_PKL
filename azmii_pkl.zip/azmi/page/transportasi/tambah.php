<div class="row">
    <div class="col-12">
        <div class="panel">
            <div class="panel-header">
                <h5>Transportasi</h5>
            </div>
            <div class="panel-body">    
                <div class="card mb-20">
                    <div class="card-header">Tambah Data Transportasi</div>
                    <div class="card-body">
                        <form method="post" enctype="multipart/form-data">
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Transportasi</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="transportasi" required>
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">&nbsp;</label>
                                <div class="col-sm-9">
                                	<button type="submit" name="tambah" class="btn btn-primary btn-sm">Simpan</button>
                                	<a href="?page=transportasi" class="btn btn-danger btn-sm">Kembali</a>
                                </div>
                            </div> 
                        </form>
                        <?php  
                         
                        if (isset($_POST['tambah'])) {
                            $transportasi = mysqli_real_escape_string($con, $_POST['transportasi']);  
                         
                            $query = "INSERT INTO transportasi (transportasi) VALUES ('$transportasi')";
                            if ($con->query($query) === TRUE) {
                                echo "<script>
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Berhasil!',
                                            text: 'Data berhasil disimpan.',
                                            confirmButtonText: 'OK'
                                        }).then((result) => {
                                            if (result.isConfirmed) {
                                                window.location.href = '?page=transportasi';
                                            }
                                        });
                                      </script>";
                            } else {
                                echo "<script>
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Gagal!',
                                            text: 'Terjadi kesalahan saat menyimpan data.',
                                            confirmButtonText: 'OK'
                                        });
                                      </script>";
                            }
                        }
                        ?>
                    </div>
                </div> 
            </div>
        </div>
    </div>
</div>  