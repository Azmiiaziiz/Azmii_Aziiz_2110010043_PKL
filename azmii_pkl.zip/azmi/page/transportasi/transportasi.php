<div class="row">
    <div class="col-12">
        <div class="panel">
            <div class="panel-header">
                <h5>Transportasi</h5>
            </div>
            <div class="panel-body">  
                <div class="card mb-20">
                    <div class="card-header">
                        Data Transportasi
                        <a href="?page=transportasi&aksi=tambah" class="btn btn-primary btn-sm float-end">Tambah</a>
                    </div>
                    <div class="card-body">
                        <table class="table table-dashed table-bordered table-hover digi-dataTable table-striped" id="componentDataTable">
                            <thead>
                                <tr>
                                    <th width="5" class="text-center">No.</th>
                                    <th style="text-align: left;">Transportasi</th>  
                                    <th width="10" class="text-center">#</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $nomor = 1; 
                                $ambil = $con->query("SELECT * FROM transportasi ORDER BY id_transportasi ASC"); 
                                while ($row = $ambil->fetch_assoc()) { ?>
                                    <tr>
                                        <td class="text-center"><?= $nomor; ?></td>
                                        <td style="text-align: left;"><?= $row['transportasi']; ?></td> 
                                        <td class="text-center">
                                            <div class="dropdown">
										        <button class="btn btn-warning dropdown-toggle btn-sm" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
										            <i class="fa-regular fa-cogs"></i>
										        </button>
										        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
										            <li><a class="dropdown-item" href="?page=transportasi&aksi=ubah&id_transportasi=<?= $row['id_transportasi'] ?>">Ubah</a></li>
										            <li><a class="dropdown-item" href="javascript:void(0)" onclick="confirmDelete(<?= $row['id_transportasi']; ?>)">Hapus</a></li>
										        </ul>
										    </div>
                                        </td>
                                    </tr>
                                <?php 
                                $nomor++; 
                                } ?>
                            </tbody>
                        </table>
                    </div>
                </div> 
            </div>
        </div>
    </div>
</div> 

<script>
function confirmDelete(id_transportasi) {
    Swal.fire({
        title: 'Apakah Anda yakin?',
        text: "Anda tidak bisa mengembalikan data yang telah dihapus!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = "?page=transportasi&aksi=hapus&id_transportasi=" + id_transportasi;
        }
    });
}
</script> 

