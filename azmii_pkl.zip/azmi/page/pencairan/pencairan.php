<div class="row">
    <div class="col-12">
        <div class="panel">
            <div class="panel-header">
                <h5>Pencairan PIP</h5>
            </div>
            <div class="panel-body">  
                <div class="card mb-20">
                    <div class="card-header">
                        Data Pencairan PIP
                        <a href="?page=pencairan&aksi=tambah" class="btn btn-primary btn-sm float-end">Tambah</a>
                    </div>
                    <div class="card-body">
                        <table class="table table-dashed table-bordered table-hover digi-dataTable table-striped" id="componentDataTable">
                            <thead>
                                <tr>
                                    <th width="5" class="text-center">No.</th>
                                    <th style="text-align: left;">Siswa</th>  
                                    <th style="text-align: left;">Bank</th>  
                                    <th style="text-align: left;">No Rekening</th>  
                                    <th style="text-align: left;">Nominal</th>   
                                    <th style="text-align: left;">SK</th>  
                                    <th style="text-align: left;">Keterangan</th>  
                                    <th style="text-align: left;">Status</th>  
                                    <th width="10" class="text-center">#</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $nomor = 1; 
                                $ambil = $con->query("SELECT * FROM pencairan NATURAL JOIN siswa NATURAL JOIN bank ORDER BY id_pencairan ASC"); 
                                while ($row = $ambil->fetch_assoc()) { 
                                $tgl = tgl_indo($row['tgl_sk']); ?>
                                    <tr>
                                        <td class="text-center"><?= $nomor; ?></td>
                                        <td style="text-align: left;">NISN : <?= $row['nisn']; ?> <br> Nama : <?= $row['nama']; ?></td> 
                                        <td style="text-align: left;"><?= $row['bank']; ?></td> 
                                        <td style="text-align: left;"><?= $row['norek']; ?></td> 
                                        <td style="text-align: left;"><?= number_format($row['nominal'], 0, ',','.') ?></td> 
                                        <td style="text-align: left;">No SK : <?= $row['no_sk']; ?> <br> Tanggal SK : <?= $tgl; ?></td> 
                                        <td style="text-align: left;">Ket : <?= $row['keterangan']; ?> <br> Pengusul : <?= $row['pengusul']; ?></td> 
                                        <td style="text-align: left;"><?= $row['status_pip']; ?></td> 
                                        <td class="text-center">
                                            <div class="dropdown">
                                                <?php if ($row['status_pip'] === 'Terdaftar'): ?>
                                                    <button class="btn btn-warning dropdown-toggle btn-sm" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                                        <i class="fa-regular fa-cogs"></i>
                                                    </button>
                                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                        <li><a class="dropdown-item" href="?page=pencairan&aksi=cair&id_pencairan=<?= $row['id_pencairan'] ?>&nisn=<?= $row['nisn'] ?>&status_pip=SK Pemberian">SK Pemberian</a></li>
                                                    </ul>
                                                <?php elseif ($row['status_pip'] === 'SK Pemberian'): ?>
                                                    <button class="btn btn-warning dropdown-toggle btn-sm" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                                        <i class="fa-regular fa-cogs"></i>
                                                    </button>
                                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                        <li><a class="dropdown-item" href="?page=pencairan&aksi=cair&id_pencairan=<?= $row['id_pencairan'] ?>&nisn=<?= $row['nisn'] ?>&status_pip=Sudah Pencairan Tahap 1">Sudah Pencairan Tahap 1</a></li>
                                                    </ul>
                                                <?php elseif ($row['status_pip'] === 'Sudah Pencairan Tahap 1'): ?>
                                                    <button class="btn btn-warning dropdown-toggle btn-sm" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                                        <i class="fa-regular fa-cogs"></i>
                                                    </button>
                                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                        <li><a class="dropdown-item" href="?page=pencairan&aksi=cair&id_pencairan=<?= $row['id_pencairan'] ?>&nisn=<?= $row['nisn'] ?>&status_pip=Sudah Pencairan Tahap 2">Sudah Pencairan Tahap 2</a></li>
                                                    </ul>
                                                <?php elseif ($row['status_pip'] === 'Sudah Pencairan Tahap 2'): ?>
                                                    <button class="btn btn-warning dropdown-toggle btn-sm" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                                        <i class="fa-regular fa-cogs"></i>
                                                    </button>
                                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                        <li><a class="dropdown-item" href="?page=pencairan&aksi=cair&id_pencairan=<?= $row['id_pencairan'] ?>&nisn=<?= $row['nisn'] ?>&status_pip=Sudah Pencairan Tahap 3">Sudah Pencairan Tahap 3</a></li>
                                                    </ul>
                                                <?php endif; ?>
                                            </div>
                                        </td>

                                    </tr>
                                <?php 
                                $nomor++; 
                                } ?>
                            </tbody>
                        </table>
                    </div>
                </div> 
            </div>


            <div class="panel-body">  
                <div class="card mb-20">
                    <div class="card-header">
                        Pencairan
                    </div>
                    <div class="card-body">
                        <table class="table table-dashed table-bordered table-hover digi-dataTable table-striped" id="componentDataTable">
                            <thead>
                                <tr>
                                    <th width="5" class="text-center">No.</th>
                                    <th style="text-align: left;">Siswa</th>  
                                    <th style="text-align: left;">Bank</th>  
                                    <th style="text-align: left;">No Rekening</th>  
                                    <th style="text-align: left;">Nominal</th>   
                                    <th style="text-align: left;">SK</th>  
                                    <th style="text-align: left;">Keterangan</th>  
                                    <th style="text-align: left;">Status</th>   
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $nomor = 1; 
                                $ambil = $con->query("SELECT * FROM tahap JOIN pencairan ON tahap.id_pencairan=pencairan.id_pencairan ORDER BY id_tahap ASC"); 
                                while ($rows = $ambil->fetch_assoc()) { 
                                $tgl = tgl_indo($rows['tglsk']); ?>
                                    <tr>
                                        <td class="text-center"><?= $nomor; ?></td>
                                        <td style="text-align: left;">NISN : 
                                                                        <?php 
                                                                        $sql_barang = mysqli_query($con, "SELECT * FROM siswa WHERE nisn = '$rows[nisn]'");
                                                                        while ($data_barang = mysqli_fetch_array($sql_barang)){
                                                                            echo "$data_barang[nisn]";
                                                                        } 
                                                                        ?> <br> 
                                                                      Nama : 
                                                                        <?php 
                                                                        $sql_barang = mysqli_query($con, "SELECT * FROM siswa WHERE nisn = '$rows[nisn]'");
                                                                        while ($data_barang = mysqli_fetch_array($sql_barang)){
                                                                            echo "$data_barang[nama]";
                                                                        } 
                                                                        ?>
                                        </td> 
                                        <td style="text-align: left;">
                                            <?php 
                                            $sql_barang = mysqli_query($con, "SELECT * FROM bank WHERE id_bank = '$rows[id_bank]'");
                                            while ($data_barang = mysqli_fetch_array($sql_barang)){
                                                echo "$data_barang[bank]";
                                            } 
                                            ?>
                                        </td> 
                                        <td style="text-align: left;"><?= $rows['norek']; ?></td> 
                                        <td style="text-align: left;"><?= number_format($rows['nominal_tahap'], 0, ',','.') ?></td> 
                                        <td style="text-align: left;">No SK : <?= $rows['nosk']; ?> <br> Tanggal SK : <?= $tgl; ?></td> 
                                        <td style="text-align: left;">Ket : <?= $rows['ket']; ?> <br> Pengusul : <?= $rows['pengusul']; ?></td> 
                                        <td style="text-align: left;"><?= $rows['status_tahap']; ?></td>  

                                    </tr>
                                <?php 
                                $nomor++; 
                                } ?>
                            </tbody>
                        </table>
                    </div>
                </div> 
            </div>
        </div>
    </div>
</div>  