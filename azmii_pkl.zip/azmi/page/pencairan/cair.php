<?php
$id_pencairan = $_GET['id_pencairan'];
$nisn = $_GET['nisn']; 
    $status_pip = $_GET['status_pip'];
$sql = $con->query("SELECT * FROM pencairan WHERE id_pencairan='$id_pencairan' AND nisn='$nisn'");
$row = mysqli_fetch_assoc($sql);
?>

<div class="row">
    <div class="col-12">
        <div class="panel">
            <div class="panel-header">
                <h5>Pencairan PIP</h5>
            </div>
            <div class="panel-body">    
                <div class="card mb-20">
                    <div class="card-header">Tambah Data Pencairan PIP</div>
                    <div class="card-body">
                        <form method="post" enctype="multipart/form-data">
                            <input type="text" class="form-control" name="id_pencairan" value="<?= $row['id_pencairan'] ?>" hidden required>
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Siswa</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="nisn" required> 
                                        <?php
                                        $sql = mysqli_query($con, "SELECT * FROM siswa WHERE nisn='$nisn'");
                                        while ($kar = mysqli_fetch_array($sql)) {
                                            $selected = ($row['nisn'] == $kar['nisn']) ? 'selected' : '';
                                            echo "<option value='$kar[nisn]' $selected>NISN : $kar[nisn] || Nama : $kar[nama]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Bank</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="id_bank" required>
                                        <option selected disabled>Pilih</option>
                                        <?php
                                        $sql = mysqli_query($con, "SELECT * FROM bank");
                                        while ($kar = mysqli_fetch_array($sql)) {
                                            $selected = ($row['id_bank'] == $kar['id_bank']) ? 'selected' : '';
                                            echo "<option value='$kar[id_bank]' $selected>$kar[bank]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">No Rekening / No Virtual</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="norek" value="<?= $row['norek'] ?>" required>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Nominal</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="nominal_tahap" id="nominal" value="<?= number_format($row['nominal'], 0, ',','.') ?>" onkeypress="return angka(event);" required >
                                    <code>Ubah nominal jika terjadi perubahan</code>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Nomor SK</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="nosk" value="<?= $row['no_sk'] ?>" required >
                                </div>
                            </div>
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Tanggal SK</label>
                                <div class="col-sm-9">
                                    <input type="date" class="form-control" name="tglsk" value="<?= $row['tgl_sk'] ?>" required >
                                </div>
                            </div>
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Keterangan</label>
                                <div class="col-sm-9">
                                    <textarea name="ket" class="form-control" required id=""><?= $row['keterangan'] ?></textarea>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Pengusul</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="pengusul" value="<?= $row['pengusul'] ?>" required >
                                </div>
                            </div>
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Status</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="status_tahap" required>
                                        <option value="Terdaftar" <?= ($row['status_pip'] == 'Terdaftar' || $_GET['status_pip'] == 'Terdaftar') ? 'selected' : ''; ?>>Terdaftar</option>
                                        <option value="SK Pemberian" <?= ($row['status_pip'] == 'SK Pemberian' || $_GET['status_pip'] == 'SK Pemberian') ? 'selected' : ''; ?>>SK Pemberian</option>
                                        <option value="Sudah Pencairan Tahap 1" <?= ($row['status_pip'] == 'Sudah Pencairan Tahap 1' || $_GET['status_pip'] == 'Sudah Pencairan Tahap 1') ? 'selected' : ''; ?>>Sudah Pencairan Tahap 1</option>
                                        <option value="Sudah Pencairan Tahap 2" <?= ($row['status_pip'] == 'Sudah Pencairan Tahap 2' || $_GET['status_pip'] == 'Sudah Pencairan Tahap 2') ? 'selected' : ''; ?>>Sudah Pencairan Tahap 2</option>
                                        <option value="Sudah Pencairan Tahap 3" <?= ($row['status_pip'] == 'Sudah Pencairan Tahap 3' || $_GET['status_pip'] == 'Sudah Pencairan Tahap 3') ? 'selected' : ''; ?>>Sudah Pencairan Tahap 3</option>
                                    </select>
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">&nbsp;</label>
                                <div class="col-sm-9">
                                	<button type="submit" name="tambah" class="btn btn-primary btn-sm">Simpan</button>
                                	<a href="?page=pencairan" class="btn btn-danger btn-sm">Kembali</a>
                                </div>
                            </div> 
                        </form>
                        <?php  
                        if (isset($_POST['tambah'])) { 
                            $id_pencairan     = $_POST['id_pencairan'];  
                            $nominal_tahap1   = $_POST['nominal_tahap'];
                            $nominal_tahap    = str_replace(".", "", $nominal_tahap1);  
                            $nosk             = $_POST['nosk'];  
                            $tglsk            = $_POST['tglsk'];  
                            $ket              = $_POST['ket'];   
                            $status_tahap       = $_POST['status_tahap'];   

                            $query_insert = "INSERT INTO tahap (id_pencairan, nominal_tahap, nosk, tglsk, ket,status_tahap) 
                                             VALUES ('$id_pencairan', '$nominal_tahap', '$nosk', '$tglsk', '$ket', '$status_tahap')";

                            if ($con->query($query_insert) === TRUE) { 
                                $query_update = "UPDATE pencairan SET status_pip='$status_tahap' WHERE id_pencairan='$id_pencairan'";
                                if ($con->query($query_update) === TRUE) { 
                                    echo "<script>
                                            Swal.fire({
                                                icon: 'success',
                                                title: 'Berhasil!',
                                                text: 'Data berhasil disimpan.',
                                                confirmButtonText: 'OK'
                                            }).then((result) => {
                                                if (result.isConfirmed) {
                                                    window.location.href = '?page=pencairan';
                                                }
                                            });
                                          </script>";
                                } else { 
                                    echo "<script>
                                            Swal.fire({
                                                icon: 'error',
                                                title: 'Gagal!',
                                                text: 'Terjadi kesalahan saat memperbarui status.',
                                                confirmButtonText: 'OK'
                                            });
                                          </script>";
                                }
                            } else { 
                                echo "<script>
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Gagal!',
                                            text: 'Terjadi kesalahan saat menyimpan data tahap.',
                                            confirmButtonText: 'OK'
                                        });
                                      </script>";
                            }
                        }
                        ?>

                    </div>
                </div> 
            </div>
        </div>
    </div>
</div>  

<script type="text/javascript">
    function angka(evt) 
    {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57)) 
        {
            return false;
        }
        return true;
    }
 

    var nominal = document.getElementById('nominal');
    nominal.addEventListener('keyup', function(e)
    {
        nominal.value = formatRupiah(this.value);
    }); 
    
    /* Fungsi */
    function formatRupiah(angka, prefix)
    {
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split    = number_string.split(','),
            sisa     = split[0].length % 3,
            rupiah     = split[0].substr(0, sisa),
            ribuan     = split[0].substr(sisa).match(/\d{3}/gi);
            
        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }
        
        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    } 
</script> 