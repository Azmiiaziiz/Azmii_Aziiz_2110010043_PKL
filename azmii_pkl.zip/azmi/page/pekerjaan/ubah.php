    
<?php
$id_pekerjaan = $_GET['id_pekerjaan'];
$sql = $con->query("SELECT * FROM pekerjaan WHERE id_pekerjaan='$id_pekerjaan'");
$row = mysqli_fetch_assoc($sql);
?>

<div class="row">
    <div class="col-12">
        <div class="panel">
            <div class="panel-header">
                <h5>Pekerjaan</h5>
            </div>
            <div class="panel-body"> 
                <div class="card mb-20">
                    <div class="card-header">Ubah Data Pekerjaan <b>"<?= $row['pekerjaan']; ?>"</b></div>
                    <div class="card-body">
                        <form method="post" enctype="multipart/form-data"> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Pekerjaan</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="pekerjaan" value="<?= $row['pekerjaan']; ?>" required>
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">&nbsp;</label>
                                <div class="col-sm-9">
                                	<button type="submit" name="ubah" class="btn btn-success btn-sm">Ubah</button>
                                	<a href="?page=pekerjaan" class="btn btn-danger btn-sm">Kembali</a>
                                </div>
                            </div> 
                        </form>
                        <?php 
                            if (isset($_POST['ubah']) && !empty($id_pekerjaan)) {
                            $pekerjaan = mysqli_real_escape_string($con, $_POST['pekerjaan']);  
                         
                            $query = "UPDATE pekerjaan SET pekerjaan='$pekerjaan' WHERE id_pekerjaan='$id_pekerjaan'";
                            if ($con->query($query) === TRUE) {
                                echo "<script>
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Berhasil!',
                                            text: 'Data berhasil diperbarui.',
                                            confirmButtonText: 'OK'
                                        }).then((result) => {
                                            if (result.isConfirmed) {
                                                window.location.href = '?page=pekerjaan';
                                            }
                                        });
                                      </script>";
                            } else {
                                echo "<script>
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Gagal!',
                                            text: 'Terjadi kesalahan saat memperbarui data.',
                                            confirmButtonText: 'OK'
                                        });
                                      </script>";
                            }
                        }
                        ?>
                    </div>
                </div> 
            </div>
        </div>
    </div>
</div> 