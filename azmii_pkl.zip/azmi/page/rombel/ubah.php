    
<?php
$id_rombel = $_GET['id_rombel'];
$sql = $con->query("SELECT * FROM rombel WHERE id_rombel='$id_rombel'");
$row = mysqli_fetch_assoc($sql);
?>

<div class="row">
    <div class="col-12">
        <div class="panel">
            <div class="panel-header">
                <h5>Rombongan Belajar</h5>
            </div>
            <div class="panel-body"> 
                <div class="card mb-20">
                    <div class="card-header">Ubah Data Rombongan Belajar <b>"<?= $row['rombel']; ?>"</b></div>
                    <div class="card-body">
                        <form method="post" enctype="multipart/form-data"> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">Rombongan Belajar</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="rombel" value="<?= $row['rombel']; ?>" required>
                                </div>
                            </div> 
                            <div class="row mb-2">
                                <label class="col-sm-3 col-form-label">&nbsp;</label>
                                <div class="col-sm-9">
                                	<button type="submit" name="ubah" class="btn btn-success btn-sm">Ubah</button>
                                	<a href="?page=rombel" class="btn btn-danger btn-sm">Kembali</a>
                                </div>
                            </div> 
                        </form>
                        <?php 
                            if (isset($_POST['ubah']) && !empty($id_rombel)) {
                            $rombel = mysqli_real_escape_string($con, $_POST['rombel']);  
                         
                            $query = "UPDATE rombel SET rombel='$rombel' WHERE id_rombel='$id_rombel'";
                            if ($con->query($query) === TRUE) {
                                echo "<script>
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Berhasil!',
                                            text: 'Data berhasil diperbarui.',
                                            confirmButtonText: 'OK'
                                        }).then((result) => {
                                            if (result.isConfirmed) {
                                                window.location.href = '?page=rombel';
                                            }
                                        });
                                      </script>";
                            } else {
                                echo "<script>
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Gagal!',
                                            text: 'Terjadi kesalahan saat memperbarui data.',
                                            confirmButtonText: 'OK'
                                        });
                                      </script>";
                            }
                        }
                        ?>
                    </div>
                </div> 
            </div>
        </div>
    </div>
</div> 